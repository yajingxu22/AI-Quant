---
name: tushare-data-fetcher
description: 通过 Tushare Pro（MCP 接口 / Python SDK）获取 A 股/港股日线数据并保存为 CSV，支持批量多标的拉取、规范化配置、移动平均线派生字段。触发词：获取股票数据、拉取日线、Tushare 取数、股票数据下载、批量取数。
agent_created: true
---

# Tushare Data Fetcher — 股票数据获取技能

## Overview

通过 **Tushare Pro** 获取股票日线行情数据，保存为标准化 CSV 文件。支持：
- A 股（沪深/科创板）和港股
- 单只或批量多标的拉取
- 规范化配置文件（YAML spec）
- 派生字段（MA5/MA10/MA20 等）
- 数据质量检查

## 触发场景

当用户说以下内容时使用本技能：
- "帮我获取 ×× 股票的数据"
- "拉取 ×× 过去一年的日线"
- "批量下载这几只股票的行情"
- "规范化取数 / 批量取数"

## 工作流程

### Step 1: 确认股票代码

先用 **Tushare MCP** 的 `stock_basic` 工具按名称查询代码：

```
mcp__tushareMcp__stock_basic(name="公司名")
```

已知常用 A 股代码速查：

| 名称 | 代码 | 市场 |
|:----|:----|:----|
| 贵州茅台 | 600519.SH | 沪市 |
| 宁德时代 | 300750.SZ | 创业板 |
| 比亚迪 | 002594.SZ | 深市 |
| 中芯国际 | 688981.SH | 科创板 |
| 长江电力 | 600900.SH | 沪市 |
| 三一重工 | 600031.SH | 沪市 |

### Step 2: 获取日线数据

通过 **Tushare MCP** 的 `daily`（A 股）或 `hk_daily`（港股）接口拉取：

```
mcp__tushareMcp__daily(ts_code="600519.SH", start_date="20250702", end_date="20260702")
```

参数说明：
- `ts_code`：股票代码，格式 `600519.SH`
- `start_date`：开始日期，格式 `YYYYMMDD`
- `end_date`：结束日期，格式 `YYYYMMDD`
- 默认字段：ts_code, trade_date, open, high, low, close, pre_close, change, pct_chg, vol, amount

**注意**：Tushare API 有频率限制（1次/分钟/接口），批量拉取多个标的时需要间隔 60 秒以上。

### Step 3: 保存数据

将返回的 JSON 数据转换为 CSV 文件存储到本地：

```python
import pandas as pd
df = pd.DataFrame(data_from_mcp)
df = df.sort_values('trade_date').reset_index(drop=True)
df.to_csv('data/raw/{ts_code}_{start}_{end}.csv', index=False, encoding='utf-8-sig')
```

文件名命名规范：`{ts_code}_{start_date}_{end_date}.csv`

### Step 4: 可选 — 生成可视化

使用 ECharts 或 Matplotlib 绘制收盘价走势面板：
- ECharts HTML：交互式折线图 + 成交量柱状图 + 缩放控件
- Matplotlib：静态图表，适合 Notebook 环境

### Step 5: 可选 — 使用规范化脚本

本技能附带两个可复用的资源文件：

**`scripts/fetch_stock_data.py`**
读取 `references/fetch_spec.yaml` 中的配置，自动拉取所有标的的数据并计算派生字段。

用法：
```bash
python scripts/fetch_stock_data.py                    # 拉取所有标的
python scripts/fetch_stock_data.py --code 600519.SH    # 单只股票
python scripts/fetch_stock_data.py --start 20250101 --end 20251231  # 自定义日期
python scripts/fetch_stock_data.py --init              # 初始化目录结构
```

**`references/fetch_spec.yaml`**
规范化配置文件，定义：
- `global`：数据源、日期范围、输出格式、命名模板
- `stocks`：标的池（名称、代码、交易所、行业）
- `fields`：字段定义（名称、类型、单位）
- `quality`：数据质量规则（缺失值、日期间隔、重复值）
- `derived_fields`：派生字段（MA5/MA10/MA20 等）
- `pipeline`：运行流程步骤

## 输出示例

```csv
ts_code,trade_date,open,high,low,close,pre_close,change,pct_chg,vol,amount
600519.SH,20250702,150.0,152.5,149.2,151.8,150.2,1.6,1.07,500000,75000000
```

## 注意事项

- **Token 配置**：Token 存储在 `~/.workbuddy/.mcp.json` 的 tushareMcp URL 中
- **频率限制**：Tushare Pro 基础版 1 次/分钟/接口，批量取数需加 `time.sleep(60)`
- **日期范围**：默认取过去一年（365 天）
- **港股数据**：使用 `mcp__tushareMcp__hk_daily` 接口，代码格式 `01810.HK`
- **复权处理**：如需前/后复权价格，调用 `mcp__tushareMcp__adj_factor` 接口获取复权因子

## Resources

### scripts/
- `fetch_stock_data.py` — 遵循 spec 的 Python 取数脚本

### references/
- `fetch_spec.yaml` — 规范化数据获取配置文件
